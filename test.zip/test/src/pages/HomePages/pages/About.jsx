import React from "react";

const About = () => {
  return <div>this is about page</div>;
};

export default About;
