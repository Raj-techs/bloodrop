import React from 'react'

const DisplayAdim = () => {
  return (
    <>
      <img src="https://theleaders-online.com/wp-content/uploads/2020/11/blood-bank.jpg" width={900} alt="" />
    </>
  )
}

export default DisplayAdim
